import socket
import sys

#constants
server_port = 6789
sys_IP = socket.gethostbyname(socket.gethostname())
Encoder = "utf-8"

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server_socket.bind((sys_IP, server_port))
server_socket.listen()

while True:
    print("Ready to serve...")
    connectionSocket, addr = server_socket.accept()

    print("----------------------------------------")
    print("Connected to host with IP : ", addr[0])

    try:
        message = connectionSocket.recv(1024).decode(Encoder)

        message = message.split()

        filename = message[1][1:]

        if(filename == 'BreakOut'):
            response = (
                'HTTP/1.1 410 Gone\r\n'
                'Content-Type: text/html\r\n\r\n'
                '<html><body><h1>410 Gone</h1>'
                '<p>Server going down...</p></body></html>'
            )
            connectionSocket.send(response.encode(Encoder))
            connectionSocket.close()
            break

        f = open(filename)

        outputdata = f.read()

        connectionSocket.send("HTTP/1.1 200 OK\r\n\r\n".encode(Encoder))

        for i in range(0, len(outputdata)):
            connectionSocket.send(outputdata[i].encode(Encoder))

        connectionSocket.send('\r\n'.encode(Encoder))
        connectionSocket.close()
    except FileNotFoundError:
        print("File not found:", filename)
        connectionSocket.send('HTTP/1.1 404 Not Found\r\n\r\n'.encode(Encoder))
        connectionSocket.send('404 File Not Found'.encode(Encoder))
        connectionSocket.close()
    except Exception as e:
        print("Error:", str(e))
        connectionSocket.send('HTTP/1.1 500 Internal Server Error\r\n\r\n'.encode(Encoder))
        connectionSocket.send('500 Internal Server Error'.encode(Encoder))
        connectionSocket.close()
    
server_socket.close()
sys.exit()