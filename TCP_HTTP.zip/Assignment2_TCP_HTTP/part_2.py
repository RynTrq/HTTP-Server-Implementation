import socket
import sys
import threading

# Constants
server_port = 6789
sys_IP = socket.gethostbyname(socket.gethostname())
Encoder = "utf-8"

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((sys_IP, server_port))
server_socket.listen()

print("----------------------------------------")
print("Ready to serve...")

def handle_client(connectionSocket, addr):
    print("Connected to host with IP : ", addr[0])

    try:
        message = connectionSocket.recv(1024).decode(Encoder)
        message = message.split()
        filename = message[1][1:]

        if filename == 'BreakOut':
            response = (
                'HTTP/1.1 410 Gone\r\n'
                'Content-Type: text/html\r\n\r\n'
                '<html><body><h1>410 Gone</h1>'
                '<p>Closing Connection...</p></body></html>'
            )
            connectionSocket.send(response.encode(Encoder))
            connectionSocket.close()
            return

        f = open(filename)
        outputdata = f.read()

        connectionSocket.send("HTTP/1.1 200 OK\r\n\r\n".encode(Encoder))

        for i in range(0, len(outputdata)):
            connectionSocket.send(outputdata[i].encode(Encoder))

        connectionSocket.send('\r\n'.encode(Encoder))
        connectionSocket.close()
    except FileNotFoundError:
        print("File not found:", filename)
        connectionSocket.send('HTTP/1.1 404 Not Found\r\n\r\n'.encode(Encoder))
        connectionSocket.send('404 File Not Found'.encode(Encoder))
        connectionSocket.close()
    except Exception as e:
        print("Error:", str(e))
        connectionSocket.send('HTTP/1.1 500 Internal Server Error\r\n\r\n'.encode(Encoder))
        connectionSocket.send('500 Internal Server Error'.encode(Encoder))
        connectionSocket.close()

while True:
    connectionSocket, addr = server_socket.accept()
    client_thread = threading.Thread(target=handle_client, args=(connectionSocket, addr))
    client_thread.start()

server_socket.close()
sys.exit()