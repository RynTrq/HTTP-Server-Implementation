import socket
import sys

if len(sys.argv) != 4:
    print("Usage: client.py server_host server_port filename")
    sys.exit(1)

# Constants
server_IP = sys.argv[1]
server_port = int(sys.argv[2])
filename = '/' + sys.argv[3]
sys_IP = socket.gethostbyname(socket.gethostname())
Encoder = "utf-8"

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client_socket.connect((server_IP, server_port))

msg_to_send = 'GET' + ' ' + filename + ' Host:' + sys_IP
client_socket.send(msg_to_send.encode(Encoder))

msg_status = client_socket.recv(1024).decode(Encoder)
msg_status = msg_status.split()
print("Status: " + msg_status[1] + " " + msg_status[2])

print("----------------------------------------")

while True:
    try:
        msg = client_socket.recv(1024).decode(Encoder)
        if not msg:
            break
        print(msg)
    except:
        break

client_socket.close()